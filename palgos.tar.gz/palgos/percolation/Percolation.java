/******************************************************************************
 *  Compilation:  javac Percolation.java
 *  Execution:    java PercolationVisualizer input.txt
 *  Dependencies: Percolation.java
 *
 *  This program takes the name of a file as a command-line argument.
 *  From that file, it
 *
 *    - Reads the grid size n of the percolation system.
 *    - Creates an n-by-n grid of sites (intially all blocked)
 *    - Reads in a sequence of sites (row i, column j) to open.
 *
 *  After each site is opened, it draws full sites in light blue,
 *  open sites (that aren't full) in white, and blocked sites in black,
 *  with with site (1, 1) in the upper left-hand corner.
 *
 ******************************************************************************/

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] sites;
    private int top;
    private int bottom;
    private int size;
    private WeightedQuickUnionUF quf;
    private int openSites;

    // create n-by-n grid, with all sites blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("negative N");
        }
        size = n;
        top = 0; // auxiliary top node
        bottom = size * size + 1; // auxiliary bottom node
        quf = new WeightedQuickUnionUF(size * size + 2);
        sites = new boolean[size][size]; // initialized to zero or blocked
        openSites = 0;
    }

    private void validateInput(int row, int col) {
        if (row <= 0 || size < row || col <= 0 || size < col) {
            throw new IndexOutOfBoundsException("row "+row+"or col "+col+" out of bounds"+size);
        }
    }

    private int get1DIndex(int row, int col) {
        return size * (row - 1) + col;
    }

    // open site (row, col) if it is not open already
    public void open(int row, int col) {
        validateInput(row, col);
        if (sites[row - 1][col - 1]) {
            return;
        }
        sites[row - 1][col - 1] = true;
        openSites++;
        if (row == 1) { // connect to virtual top
            quf.union(get1DIndex(row, col), top);
        }
        if (row == size) { // connect to virtual bottom
            quf.union(get1DIndex(row, col), bottom);
        }
        if (col > 1 && isOpen(row, col - 1)) {
            quf.union(get1DIndex(row, col), get1DIndex(row, col - 1));
        }
        if (col < size && isOpen(row, col + 1)) {
            quf.union(get1DIndex(row, col), get1DIndex(row, col + 1));
        }
        if (row > 1 && isOpen(row - 1, col)) {
            quf.union(get1DIndex(row, col), get1DIndex(row - 1, col));
        }
        if (row < size && isOpen(row + 1, col)) {
            quf.union(get1DIndex(row, col), get1DIndex(row + 1, col));
        }
    }

    // is site (row, col) open?
    public boolean isOpen(int row, int col) {
        validateInput(row, col);
        return sites[row - 1][col - 1];
    }

    // is site (row, col) full or connected to virtual top site?
    public boolean isFull(int row, int col) {
        validateInput(row, col);
        return quf.connected(top, get1DIndex(row, col));
    }

    // number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }
    // does the system percolate?
    public boolean percolates() {
        return quf.connected(top, bottom);
    }

    // test client (optional)
    public static void main(String[] args) {
    }
}
