#include<iostream>
#include<vector>
using namespace std;

struct TreeNode {
    TreeNode() : left(nullptr), right(nullptr), data(0) {}
    TreeNode(TreeNode *l, TreeNode *r) : left(l), right(r) {}
    struct TreeNode *left;
    struct TreeNode *right;
    int data;
};

class Solution {
    public:
    int diameterHelper(TreeNode *root, int &height) {
        if (!root) {
            return 0;
        }
        int leftH = 0;
        int leftD = diameterHelper(root->left, leftH);
        int rightH = 0;
        int rightD = diameterHelper(root->left, rightH);
        int max = leftD;
        if (leftD < rightD) {
            max = rightD;
        }
        if (max < leftH + rightH) {
            max = leftH;
        }

        if (rightD && leftH < rightH) {
            height = rightH + 1;
        } else if (leftD && rightH < leftH) {
            height = leftH + 1;
        }
        return max;
    }

    int diameter(TreeNode *root) {
        int height = 0;
        int ans = diameterHelper(root, height);
        cout << " Height = "<<height<<endl;
        return ans;
    }
};

int main() {
    /*
            R
          /  \
         A    H
        / \
       B   C
      /     \
     D       E
    /         \
   F           G
    */

    TreeNode F, G, H;
    TreeNode D(&F, nullptr), E(nullptr, &G);
    TreeNode B(&D, nullptr), C(nullptr, &E);
    TreeNode A(&B, &C);
    TreeNode R1(&A, &H);
    Solution s;
    cout<<"Diameter of tree 1 is "<<s.diameter(&R1)<<endl;
    /*
         A  
        / \
       B   C
      /     \
     D       E
    */
    cout<<"Diameter of tree 2 is "<<s.diameter(&A)<<endl;
    cout<<"Diameter of tree 3 is "<<s.diameter(&E)<<endl;
    return 0;
}
