#include<list>
#include<vector>
#include<iostream>

using namespace std;
/**
 * Definition for a binary tree node.
 */

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

class Solution {
public:
    bool isQ1;
    list<TreeNode *> q1, q2;
    list<TreeNode *> & getCurQ() {
        if (isQ1) return q1;
        return q2;
    }
    list<TreeNode *> & getOtherQ() {
        if (isQ1) return q2;
        return q1;
    }
    bool symmetric(list<TreeNode*> &q) {
        auto f = q.begin();
        auto b = q.rbegin();
        int i = 0;
        int n = q.size() / 2;
        for (int i = 0; i <= n; f++, b++, i++) {
            TreeNode *front = *f;
            TreeNode *back = *b;
            if (!front && !back) continue;
            if (front && back && front->val == back->val) continue;
            else return false;
        }
        return true;
    }
    void swapQ() { isQ1 = !isQ1;}
    bool isSymmetric(TreeNode* root) {
        if (!root || root->left == root->right) return true; 
        
        isQ1 = true;
        q1.push_back(root);
        while (!getCurQ().empty()) {
            TreeNode *cur = getCurQ().front();
            getCurQ().pop_front();
            if (cur && (cur->left || cur->right)) {
                getOtherQ().push_back(cur->left);
                getOtherQ().push_back(cur->right);
            }
            if (getCurQ().empty()) {
                if (!symmetric(getOtherQ())) return false;
                swapQ();
            }
        }
        return true;
    }
};

int main() {
    TreeNode root(1);
    TreeNode l11(2), l12(2); root.left = &l11; root.right = &l12;
    TreeNode l22(3), l24(3); l11.right = &l22; l12.right = &l24;
    Solution s;
    cout<<"Is Tree Symmetric"<<s.isSymmetric(&root)<<endl;

    return 0;
}
