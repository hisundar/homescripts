
void setup(const std::vector<std::string>& dict)

    std::vector<std::string> lookup(const std::string& input);
    //"__R__W_"




    // usage
    HangmanSolver h;
    h.setup(dict);


    // _ A _ S
    // CATS , BATS
    // _ A _
    // 
    //                                   index of the vector
    // (C, 0), (A, 1), (T, 2), (S, 3) => 1
    // (B, 0), (A, 1), (T, 2), (S, 3) => 2
    // 
    //  
    std::unordered_map<std::pair<char, int>, std::vector<int>> hash;
    ...
    // W: 0 --- 3 --- 8
    // T : -----3-----7

    h.lookup("__W__T_");
    h.lookup("__R__");

    class HangmanSolver {
        std::unordered_map<std::pair<char, int>, std::vector<int>> hash;
        void setup(const std::vector<std::string>& dict) {
            for (std::vector<std::string>::iterator it = dict.begin(); it != dict.end(); it++) {
                const char *word = (*it).c_str();
                int len = (*it).size();
                for (int i = len - 1; i >=0; --i) {
                    std::vector<int> &query = hash[std::make_pair(word[i], i)];
                    query.push_back(it - dict.begin());
                }
            }
        }

        std::vector<std::string> lookup(const std::string& input) {
            const char *word = input.c_str();
            int len = input.size();
            std::vector<std::vector<int>> ans;
            for (i = len - 1; i >=0 ; --i) {
                if (word[i] != "_") {
                    std::vector<int> &query = hash[std::make_pair(word[i], i)];
                    ans.push_back(query);
                }
            }
            // c0: 0 -- 3 -- 7
            // c1: 1 -- 3 ---7 -- 9 -- 19
            // c2: 3 -- 7 
            std::vector<std::string> ret;
            bool done = false;
            for (i = 0; i < ans.size();i++) {
                bool lookup = ans[i];
                for (j = i + 1; j < ans.size();i++) {
                    bool ok = true;
                    for (j = i + 1; j < ans[i].size(); j++) {
                        if (ans[i][j] != ans[i][j - 1]) {
                            ok  = false;
                            break;
                        }
                    }
                    if (ok) {
                        ret.push_back(dict[i]);
                    }
                }
                return ret;
            }



        }
