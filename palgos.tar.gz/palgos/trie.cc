#include<iostream>
#include<cmath>
#include<string>
#include<vector>
#include<set>
#include<unordered_set>
#include<unordered_map>
#include<map>
using namespace std;

#define CHARS 26
class Trie {
    Trie *chars[CHARS];
    bool isWord;
public:
    /** Initialize your data structure here. */
    Trie() {
        for (int i = 0; i < CHARS; i++) {
            chars[i] = 0;
            isWord = false;
        }
    }

    /** Inserts a word into the trie. */
    void insert(string word) {
        auto *cur = this;
        for (const char c : word) {
            int cidx = c - 'a';
            if (!cur->chars[cidx]) {
                cur->chars[cidx] = new Trie();
                cur = cur->chars[cidx];
            }
        }
        cur->isWord = true;
    }

    /** Returns if the word is in the trie. */
    bool search(string word) {
        auto *cur = this;
        for (const char c : word) {
            int cidx = c - 'a';
            if (cur->chars[cidx]) {
                cur = cur->chars[cidx];
            } else {
                return false;
            }
        }
        return cur->isWord;
    }

    /** Returns if there is any word in the trie that starts with the given prefix. */
    bool startsWith(string prefix) {
        auto *cur = this;
        for (const auto c : prefix) {
            int cidx = c - 'a';
            if (cur->chars[cidx]) {
                cur = cur->chars[cidx];
            } else {
                return false;
            }
        }
        return true;
    }
};

int main() {
    Trie obj;
    obj.insert(string("word"));
    bool param_2 = obj.search("word");
    cout<<" word present "<< param_2<<endl;
    bool param_3 = obj.startsWith("wor");
    cout<<" wor prefix "<< param_3<<endl;
    return 0;
}
