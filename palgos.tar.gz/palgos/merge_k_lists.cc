#include<iostream>
#include<vector>
#include<queue>
#include<queue>
using namespace std;

class ListNode {
    public:
     int val;
     ListNode *next;
     ListNode(int x) : val(x), next(NULL) {}
};

class Solution {
public:
    ListNode* mergeKLists(vector<ListNode*>& lists) {
        ListNode *head = nullptr;
        priority_queue<pair<int,int>, vector<pair<int,int> >, greater<pair<int,int> > > Q;
        if (lists.empty()) return nullptr;
        if (lists.size() == 1) return lists[0];
        
        for (int i = 0; i < lists.size(); i++) {
            if (lists[i] != nullptr) {
                Q.push(make_pair(lists[i]->val, i));
            }
        }
        ListNode *curr = head;
        while (!Q.empty()) {
            auto i = Q.top();
            Q.pop();
            ListNode *node = lists[i.second];
            lists[i.second] = lists[i.second]->next;
            if (lists[i.second]) {
                Q.push(make_pair(lists[i.second]->val, i.second));
            }
            if (!curr) {
                curr = node;
                head = node;
            } else {
                curr->next = node;
                curr = node;
            }
        }
        curr->next = nullptr;
        return head;
    }
    
};

int main() {
    vector<ListNode *> lists;
    
    // [[1,4,5],[1,3,4],[2,6]]
    ListNode *a,*b,*c;
    a = new ListNode(1);
    b = new ListNode(4);
    c = new ListNode(5);
    a->next = b;
    b->next = c;
    lists.push_back(a);

    a = new ListNode(1);
    b = new ListNode(3);
    c = new ListNode(4);
    a->next = b;
    b->next = c;
    lists.push_back(a);

    a = new ListNode(2);
    b = new ListNode(6);
    a->next = b;
    lists.push_back(a);

    Solution S;
    S.mergeKLists(lists);
}
