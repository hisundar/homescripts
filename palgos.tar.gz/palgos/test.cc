#include<iostream>
#include<cmath>
#include<string>
#include<vector>
#include<set>
#include<unordered_set>
#include<unordered_map>
#include<map>
#include<algorithm>
using namespace std;

int main() {
    return 0;
}
