/******************************************************************************
 *  Compilation:  javac Deque.java
 *  Execution:    java Deque
 *
 ******************************************************************************/

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private int qSize; // number of elements on queue
    private Node front; // beginning of queue
    private Node rear; // end of queue

    private class Node {
        private Item item;
        private Node prev;
        private Node next;
    }

    public Deque() {
        front = null;
        rear = null;
        qSize = 0;
    }

    public boolean isEmpty() {
        return (front == null && rear == null);
    }

    public int size() {
        return qSize;
    }

    public void addFirst(Item item) {
        if (item == null)
            throw new java.lang.NullPointerException();
        boolean empty = isEmpty();
        Node oldFirst = front;
        front = new Node();
        front.item = item;
        front.next = oldFirst;
        front.prev = null;
        if (empty) {
            rear = front;
        } else {
            oldFirst.prev = front;
        }
        ++qSize;
    }

    public void addLast(Item item) {
        if (item == null)
            throw new java.lang.NullPointerException();
        boolean empty = isEmpty();
        Node oldLast = rear;
        rear = new Node();
        rear.item = item;
        rear.prev = oldLast;
        if (!empty) {
            oldLast.next = rear;
        } else {
            front = rear;
        }
        ++qSize;
    }

    public Item removeFirst() {
        if (isEmpty())
            throw new java.util.NoSuchElementException();
        Node next = front.next;
        Item result = front.item;
        if (next != null) {
            next.prev = null;
        }
        if (front == rear) {
            rear = next;
        }
        front = next;
        --qSize;
        return result;
    }

    public Item removeLast() {
        if (isEmpty())
            throw new java.util.NoSuchElementException();
        Node prev = rear.prev;
        Item result = rear.item;
        if (prev != null)
            prev.next = null;
        if (front == rear) {
            front = null;
        }
        rear = prev;
        --qSize;
        return result;
    }

    public Iterator<Item> iterator() {
        return new QIterator();
    }

    private class QIterator implements Iterator<Item> {
        private Node current = front;

        public boolean hasNext() {
            return current != null;
        }
        
        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            if (!hasNext())
                throw new NoSuchElementException();
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

    // unit testing (optional)
    public static void main(String[] args) {
    }
}

