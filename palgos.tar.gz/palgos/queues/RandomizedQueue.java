/******************************************************************************
 *  Compilation:  javac RandomizedQueue.java
 *  Execution:    java Deque
 *
 ******************************************************************************/

import java.util.Random;
import edu.princeton.cs.algs4.StdRandom;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] qArray;
    private int qSize = 0;
    private Random qRand = new Random();

    // construct an empty randomized queue
    //@SuppressWarnings("unchecked")
    public RandomizedQueue() {
        qArray = (Item[]) new Object[2];
    }

    // is the queue empty?
    public boolean isEmpty() {
        return (qSize == 0);
    }

    // return the number of items on the queue
    public int size() {
        return qSize;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null)
            throw new NullPointerException();
        if (qSize == qArray.length)
            resize(2 * qArray.length);
        qArray[qSize++] = item;
    }

    //@SuppressWarnings("unchecked")
    private void resize(int newQueueSize) {
        Item[] newQArray = (Item[]) new Object[newQueueSize];
        for (int i = 0; i < qSize; i++) {
            newQArray[i % newQueueSize] = qArray[i % qArray.length];
        }
        qArray = newQArray;
        newQArray = null;
    }

    // remove and return a random item
    public Item dequeue() {
        if (isEmpty())
            throw new NoSuchElementException("No more elements");
        int randomElementIndex = qRand.nextInt(qSize--);
        Item item = qArray[randomElementIndex];
        qArray[randomElementIndex] = qArray[qSize];
        qArray[qSize] = null;

        if (qSize > 0 && qSize <= qArray.length / 4)
            resize(qArray.length / 2);
        return item;
    }

    // return (but do not remove) a random item
    public Item sample() {
        if (isEmpty())
            throw new NoSuchElementException("Nothing to sample");
        return qArray[qRand.nextInt(qSize)];
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new JIterator();
    }

    // unit testing (optional) {
    public static void main(String[] args) {
    }

    private class JIterator implements Iterator<Item> {
        private int curQSize = 0;
        private int[] indexArray;

        public JIterator() {
            indexArray = new int[qSize];
            for (int i = 0; i < indexArray.length; i++) {
                indexArray[i] = i;
            }
            StdRandom.shuffle(indexArray);
        }

        public boolean hasNext() {
            return qSize > curQSize;
        }

        @Override
        public Item next() {
            if (hasNext()) {
                return qArray[indexArray[curQSize++]];
            }
            throw new NoSuchElementException();
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
