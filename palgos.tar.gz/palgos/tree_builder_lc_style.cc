#include<vector>
#include<string>
#include<sstream>
#include<iostream>
using namespace std;
/**
 * Definition for a binary tree node.
 */
 struct TreeNode {
     int val;
     TreeNode *left;
     TreeNode *right;
     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

class Codec {
public:

    // Encodes a tree to a single string.
    string serialize(TreeNode* root) {
        ostringstream data;
        data<<"[";
        if (root) {
            vector<TreeNode *> Q[2];
            int curq = 0;
            Q[curq].push_back(root);
            bool first = true;
            while (!Q[curq].empty()) {
                // cout<<"------Level"<<curq<<"----------"<<endl;
                int otherq = !curq;
                bool leafLevel = true;
                for (int i = 0; i < Q[curq].size(); i++) {
                    TreeNode *node = Q[curq][i];
                    // cout<<"i("<<(node?node->val:0)<<" ";
                    if (first) {
                        first = false;
                    } else {
                        data<<",";
                    }
                    if (node) {
                        data<<node->val;
                        // cout<<node->val<<" ";
                        Q[otherq].push_back(node->left);
                        Q[otherq].push_back(node->right);
                        if (node->left || node->right) leafLevel = false;
                    } else {
                        data<<"null";
                    }
                }
                Q[curq].clear();
                if (leafLevel) break;
                curq = otherq;
            }
        }
        
        data<<"]";
        // cout<<data.str();
        return data.str();
        
    }
    TreeNode *getNextNode(string data, int &pos) {
        int strStart = ++pos;
        for (; data[pos] != ',' && data[pos] != ']'; pos++);
        if (strStart >= pos) return nullptr;
        const string nod = data.substr(strStart, pos - 1);
        //cout<<"{"<<nod<<"}"<<strStart<<" - "<<pos<<endl;
        if (nod[0] != 'n') {
            int val = stoi(nod);
            return (new TreeNode(val));
        }
        return nullptr;
    }

    // Decodes your encoded data to tree.
    TreeNode* deserialize(string data) {
        int pos = 0;
        TreeNode *top_root = getNextNode(data, pos);
        if (!top_root) return top_root;
        
        vector<TreeNode *> Q[2];
        int curq = 0;
        Q[curq].push_back(top_root);
        while (!Q[curq].empty()) {
            int otherq = !curq;
            bool leafLevel = true;
            //cout<<"---------"<<endl;
            for (int i = 0; i < Q[curq].size(); i++) {
                TreeNode *node = Q[curq][i];
                if (pos < data.size() - 1) {
                    TreeNode *left = getNextNode(data, pos);
                    TreeNode *right = getNextNode(data, pos);
                    if (left) {
                        Q[otherq].push_back(left);
                        leafLevel = false;
                        node->left = left;
                    }
                    if (right) {
                        Q[otherq].push_back(right);
                        leafLevel = false;
                        node->right = right;
                    }
                } else break;
            }
            Q[curq].clear();
            if (leafLevel) break;
            curq = otherq;
        }
        return top_root;    
    }
};

int main() {
    string tree("[1,2,3]");
    Codec c;
    TreeNode *root = c.deserialize(tree);
    string back = c.serialize(root);
    cout<<back<<endl;
}
