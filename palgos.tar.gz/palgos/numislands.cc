#include<iostream>
#include<stack>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;

class Solution {
public:
    void explore(int row, int col, vector<vector<char> >& grid,
                vector<vector<bool> >& seen) {
        seen[row][col] = true;
        if (row > 0 && grid[row - 1][col] && !seen[row - 1][col]) {
            explore(row - 1, col, grid, seen);
        }
        if (col > 0 && grid[row][col - 1] && !seen[row][col - 1]) {
            explore(row, col - 1, grid, seen);
        }
        if (row < (grid.size() - 1) &&
            grid[row+1][col] &&
            !seen[row+1][col]) {
            explore(row +1, col, grid, seen);
        }
        if (col < (grid[0].size() - 1) && grid[row][col+1] && !seen[row][col+1]) {
            explore(row, col+1, grid, seen);
        }
    }
    int numIslands(vector<vector<char> >& grid) {
        int ans = 0;
        if (grid.size() == 0) return ans;
        if (grid.size() == 1 && grid[0].size() == 1) return grid[0][0] - '0';
        vector< vector<bool> > seen(grid.size(), vector<bool>(grid[0].size()));
        for (int row = 0; row < grid.size(); row++) {
            for (int col = 0; col < grid[0].size(); col++) {
                if (!seen[row][col]) {
                    if (grid[row][col]) {
                        ans++;
                        explore(row, col, grid, seen);
                    }
                }
            }
        }
        return ans;
    }
};

int main() {
    vector< vector<char> > grid(1, vector<char>(2));
    grid[0][0] = '1';
    grid[0][1] = '0';
    Solution s;
    cout<<"Grid size = "<<grid.size()<<endl;
    cout<<s.numIslands(grid)<<endl;
}
