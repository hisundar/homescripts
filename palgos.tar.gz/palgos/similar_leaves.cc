#include<iostream>
#include<stack>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;

class TreeNode {
    public:
     int val;
     TreeNode *left;
     TreeNode *right;
     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

class SimilarLeaves {
public:
    TreeNode* mergeKLists(vector<TreeNode*>& lists) {
        TreeNode *head = nullptr;
        priority_queue<pair<int,int>, vector<pair<int,int> >, greater<pair<int,int> > > Q;
        if (lists.empty()) return nullptr;
        if (lists.size() == 1) return lists[0];
        
        for (int i = 0; i < lists.size(); i++) {
            if (lists[i] != nullptr) {
                Q.push(make_pair(lists[i]->val, i));
            }
        }
        TreeNode *curr = head;
        while (!Q.empty()) {
            auto i = Q.top();
            Q.pop();
            TreeNode *node = lists[i.second];
            lists[i.second] = lists[i.second]->next;
            if (lists[i.second]) {
                Q.push(make_pair(lists[i.second]->val, i.second));
            }
            if (!curr) {
                curr = node;
                head = node;
            } else {
                curr->next = node;
                curr = node;
            }
        }
        curr->next = nullptr;
        return head;
    }
    
};

int main() {
    vector<TreeNode *> lists;
    
    // [[1,4,5],[1,3,4],[2,6]]
    TreeNode *a,*b,*c;
    a = new TreeNode(1);
    b = new TreeNode(4);
    c = new TreeNode(5);
    a->next = b;
    b->next = c;
    lists.push_back(a);

    a = new TreeNode(1);
    b = new TreeNode(3);
    c = new TreeNode(4);
    a->next = b;
    b->next = c;
    lists.push_back(a);

    a = new TreeNode(2);
    b = new TreeNode(6);
    a->next = b;
    lists.push_back(a);

    Solution S;
    S.mergeKLists(lists);
}
